﻿namespace Vehicles.Core
{
    using Constants;
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double litresPerKm) 
            : base(fuelQuantity,litresPerKm)
        {
            this.LitresPerKm += AirConditionerFuelIncrement;
        }

        public override double AirConditionerFuelIncrement => FuelIncrement.Car;

        public override void Refuel(double litres) => this.FuelQuantity += litres;
    }
}
