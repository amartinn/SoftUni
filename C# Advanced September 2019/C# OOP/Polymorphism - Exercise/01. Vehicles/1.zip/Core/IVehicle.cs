﻿namespace Vehicles.Core
{
     public interface IVehicle
    {
        public double FuelQuantity { get; }
        public double LitresPerKm { get; }
        abstract void Refuel(double litres);
        string Drive(double km);
        public abstract double AirConditionerFuelIncrement { get; }
    }
}
