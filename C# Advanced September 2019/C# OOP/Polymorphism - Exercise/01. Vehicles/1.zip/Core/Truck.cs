﻿namespace Vehicles.Core
{
    using Constants;
    public class Truck : Vehicle
    {
        private const double truckTankHoleFuelLoose = 0.95;
        public Truck(double fuelQuantity, double litresPerKm) 
            : base(fuelQuantity, litresPerKm)
        {
            this.LitresPerKm += AirConditionerFuelIncrement;
            
        }

        public override double AirConditionerFuelIncrement => FuelIncrement.Truck;
        public override void Refuel(double litres)
        {
            this.FuelQuantity += litres * truckTankHoleFuelLoose;   
        }

    }
}
