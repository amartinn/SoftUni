﻿namespace Vehicles.Core
{
    using Constants;
    public abstract class Vehicle : IVehicle
    {
        protected Vehicle(double fuelQuantity, double litresPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            this.LitresPerKm = litresPerKm;
        }

        public double FuelQuantity { get; protected set; }

        public double LitresPerKm { get; protected set; }

        public abstract double AirConditionerFuelIncrement { get; }

        public string Drive(double distance)
        {
            string message = string.Empty;
            bool canDrive = this.FuelQuantity >= this.LitresPerKm * distance;
            if (canDrive)
            {
                this.FuelQuantity -= LitresPerKm * distance;
                message = string.Format(ConstantMessages.VehicleTravel, this.GetType().Name, distance);
            }
            else
            {
                message = string.Format(ConstantMessages.VehicleRefuel, this.GetType().Name);
            }
            return message;
        }
        public abstract void Refuel(double litres);

        public override string ToString()
        {
            return $"{this.GetType().Name}: {this.FuelQuantity:f2}";
        }
    }
}
