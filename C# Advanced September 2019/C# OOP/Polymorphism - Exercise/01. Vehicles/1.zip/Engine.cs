﻿namespace Vehicles
{
    using IO;
    using Core;
    using Factory;
    using Constants;

    using System;
    using System.Reflection;
    class Engine : IEngine
    {
        public void Run(VehicleFactory factory,IConsoleWriter writer,IConsoleReader reader)
        {

            var carInfo = reader.ReadLine().Split();
            var carName = carInfo[0];
            var carFuelQuantity = double.Parse(carInfo[1]);
            var carLitresPerKm = double.Parse(carInfo[2]);
            IVehicle car = factory.Create(carName, carFuelQuantity, carLitresPerKm);


            var truckInfo = reader.ReadLine().Split();
            var truckName = truckInfo[0];
            var truckFuelQuantity = double.Parse(truckInfo[1]);
            var truckLitresPerKm = double.Parse(truckInfo[2]);

            IVehicle truck = factory.Create(truckName, truckFuelQuantity, truckLitresPerKm);

            var numberOfCommands = int.Parse(reader.ReadLine());
            for (int i = 0; i < numberOfCommands; i++)
            {
                var command = reader.ReadLine().Split();
                var commandType = command[0];
                var vehicleName = command[1];
                var vehicleType  = Type.GetType($"{typeof(StartUp).Namespace}.Core.{vehicleName}");

                IVehicle vehicle = car.GetType().Name == vehicleType.Name ? car : truck;
                if (commandType == ConstantMessages.DriveMethodName)
                {
                    var distance = double.Parse(command[2]);

                    var message = Drive(distance, vehicleType, vehicle);
                    writer.WriteLine(message);
                }
                else
                {
                    var fuel = double.Parse(command[2]);
                    vehicleType.GetMethod(ConstantMessages.RefuelMethodName,
                                      BindingFlags.Public | BindingFlags.Instance)
                                        .Invoke(vehicle, new object[] { fuel});

                }
            }
            writer.WriteLine(car);
            writer.WriteLine(truck);
        }
        private string Drive(double distance, Type vehicleType, IVehicle vehicle)
        {
            var method = vehicleType.GetMethod(ConstantMessages.DriveMethodName,
        BindingFlags.Public | BindingFlags.Instance);
            var message = method.Invoke(vehicle, new object[] { distance });
            return (string)message;
        }
    }

}
