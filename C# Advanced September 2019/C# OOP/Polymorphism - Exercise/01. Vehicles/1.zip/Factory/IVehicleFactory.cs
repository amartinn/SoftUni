﻿namespace Vehicles.Factory
{
    using Vehicles.Core;
    public interface IVehicleFactory
    {
        IVehicle Create(string type,double fuel, double distance);
    }
}
