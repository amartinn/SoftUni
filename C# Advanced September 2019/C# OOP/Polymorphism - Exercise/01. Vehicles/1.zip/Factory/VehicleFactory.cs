﻿namespace Vehicles.Factory
{
    using Vehicles.Core;
    using System;
    public class VehicleFactory : IVehicleFactory
    {
        public IVehicle Create(string type, double fuel, double distance)
        {
           IVehicle vehicle = Activator
                .CreateInstance(Type.GetType(typeof(StartUp).Namespace + ".Core." + type)
                ,new object[] { fuel, distance }) as IVehicle;
            return vehicle;
        }
    }
}
