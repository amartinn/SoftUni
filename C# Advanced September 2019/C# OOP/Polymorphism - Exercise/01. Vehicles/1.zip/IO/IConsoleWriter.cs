﻿namespace Vehicles.IO
{
    public interface IConsoleWriter
    {
        void WriteLine(object obj);
    }
}
