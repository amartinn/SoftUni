﻿namespace Vehicles.IO
{
    public interface IConsoleReader
    {
        string ReadLine();
    }
}
