﻿namespace Vehicles.Constants
{
   public static  class FuelIncrement
    {
        public static double Car => 0.9;
        public static double Truck => 1.6;
        public static double Bus => 1.4;
    }
}
