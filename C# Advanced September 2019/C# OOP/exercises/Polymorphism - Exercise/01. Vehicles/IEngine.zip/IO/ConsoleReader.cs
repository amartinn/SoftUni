﻿namespace Vehicles.IO
{
    using System;
    class ConsoleReader : IConsoleReader
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }
    }
}
