export const firebaseConfig = {
	apiKey: 'AIzaSyABx7dDEi9Jzqkwi-ZyzvWAzURaXe5qlhQ',
	authDomain: 'softuni-exam-e3c89.firebaseapp.com',
	databaseURL: 'https://softuni-exam-e3c89.firebaseio.com',
	projectId: 'softuni-exam-e3c89',
	storageBucket: 'softuni-exam-e3c89.appspot.com',
	messagingSenderId: '113303134493',
	appId: '1:113303134493:web:d4c1829e836fd34ac641f4'
};
export const apiKey = 'https://softuni-exam-e3c89.firebaseio.com/';
