Hello Softuni Team,

Thank you for the quick answers on slido!
You can change the firebase config/apikey in './firebaseConfig.js' file, or use mine.s
You can find the available routes below:

#/ or #/home -> will use './templates/home' template and will call './scripts/handlers/home.js'-> homeHandler.

#/register -> will use './templates/auth/register' template and will call './scripts/handlers/auth.js' -> registerHandler.

#/login -> will use './templates/auth/login' template and will call './scripts/handlers/auth.js' -> loginHandler.

#/logout -> will use './templates/auth/login' template and will call './scripts/handlers/auth.js' -> logoutHandler.

#/create -> will use './templates/crud/create' template and will call './scripts/handlers/create.js' -> createHandler.

#/articles/{category}/edit/{id} -> will use './templates/crud/edit' template and will call './scripts/handlers/edit.js' -> editHandler.

#/articles/{category}/details/{id} -> will use './templates/articles/details' template and will call './scripts/handlers/details.js' -> detailsHandler.

#/articles/{category}/delete/{id} -> will use './templates/articles/details' template and will call './scripts/handlers/delete.js' -> deleteHandler.

Since I had much more time than expected, I decided to add notifications also.

I've also created a test user in case of an unexpected error:
    email:testuser@test.com
    password:testuser

I would like to get feedback if it is possible on my email: martoy123691@gmail.com

Best Regards,
Martin Angelov